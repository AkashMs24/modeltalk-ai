# 🧠 Explainable AI Copilot — Loan Credit Risk

> **"Business users can understand AI decisions in plain English."**

An enterprise-grade AI system combining **Explainable AI**, **Bias Detection**, and a **Decision Appeal Engine** — built on top of a real loan credit risk model.

---

## 🏗️ Architecture

```
xai-copilot/
├── backend/                  # FastAPI + Python ML
│   ├── app/
│   │   ├── api/              # REST endpoints
│   │   │   ├── predict.py    # ML prediction
│   │   │   ├── explain.py    # SHAP explainability
│   │   │   ├── bias.py       # Disparate impact analysis
│   │   │   ├── appeal.py     # Decision appeal + counterfactuals
│   │   │   └── chat.py       # LLM copilot chat
│   │   ├── core/             # Model loader singleton
│   │   ├── models/           # Pydantic schemas
│   │   └── services/         # Groq LLM integration
│   ├── train_model.py        # Train + save ML artifacts
│   └── requirements.txt
├── frontend/                 # React + Vite + Tailwind
│   └── src/
│       ├── pages/            # Dashboard, Predict, Bias, Appeal, Chat
│       ├── components/       # Layout, Sidebar
│       └── services/         # API client
├── render.yaml               # Render deployment config
└── README.md
```

## 🚀 Features

| Module | What It Does |
|---|---|
| **Predict & Explain** | ML prediction + SHAP waterfall chart + LLM plain-English explanation |
| **Bias Detection** | Disparate impact ratios by gender, ethnicity, zip region. Flags groups below 80% threshold |
| **Decision Appeal** | Counterfactual analysis — finds minimal changes to flip rejection → approval |
| **AI Copilot Chat** | Ask anything about your decision in plain English via LLaMA 3 70B |

## 🛠️ Tech Stack

- **ML**: Scikit-learn (Gradient Boosting), SHAP, Pandas, NumPy
- **Backend**: FastAPI, Uvicorn, Pydantic v2
- **LLM**: Groq API + LLaMA 3 70B (free tier)
- **Frontend**: React 18, Vite, Tailwind CSS, Recharts
- **Deploy**: Render (free tier)

---

## ⚡ Local Setup

### Prerequisites
- Python 3.10+
- Node.js 18+
- [Groq API Key](https://console.groq.com) (free)

### 1. Clone & Setup Backend
```bash
git clone https://github.com/YOUR_USERNAME/xai-copilot.git
cd xai-copilot/backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variable
cp .env.example .env
# Edit .env and add your GROQ_API_KEY

# Train the model (creates data/ artifacts)
python train_model.py

# Start backend server
uvicorn app.main:app --reload --port 8000
```

Backend runs at: `http://localhost:8000`
API Docs at: `http://localhost:8000/docs`

### 2. Setup Frontend
```bash
cd ../frontend
npm install
npm run dev
```

Frontend runs at: `http://localhost:5173`

---

## 🌐 Deploy to Render (Free)

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/xai-copilot.git
git push -u origin main
```

### Step 2: Deploy Backend
1. Go to [render.com](https://render.com) → New → Web Service
2. Connect your GitHub repo
3. Settings:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt && python train_model.py`
   - **Start Command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Add Environment Variable:
   - `GROQ_API_KEY` → your key from console.groq.com

### Step 3: Deploy Frontend
1. New → Static Site
2. Connect same repo
3. Settings:
   - **Root Directory**: `frontend`
   - **Build Command**: `npm install && npm run build`
   - **Publish Directory**: `dist`
4. Add Environment Variable:
   - `VITE_API_URL` → `https://YOUR-BACKEND-NAME.onrender.com/api/v1`

> ⚠️ **Render Free Tier**: Backend spins down after 15 min inactivity. First request may take ~30s cold start.

---

## 📊 API Reference

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/predict` | Loan risk prediction |
| POST | `/api/v1/explain` | SHAP explanation + LLM summary |
| GET | `/api/v1/bias-report` | Full demographic bias report |
| POST | `/api/v1/appeal` | Decision appeal + counterfactuals |
| POST | `/api/v1/chat` | AI copilot chat |

Full docs: `http://localhost:8000/docs`

---

## 🎯 Resume Talking Points

- **XAI**: Used SHAP TreeExplainer to generate feature-level attributions for every prediction
- **Fairness**: Implemented disparate impact analysis (80% rule) across 3 demographic axes
- **Counterfactuals**: Built algorithmic counterfactual engine that finds minimal changes to flip decisions
- **RAG-style context**: LLM is grounded with SHAP values + application data — no hallucination
- **Production-ready**: FastAPI async backend, Pydantic validation, CORS, singleton model loading
- **Deployed**: Live on Render with CI/CD via GitHub

---

## 📄 License

MIT — free to use, modify, and showcase.

---

## 📦 Push to GitHub (Step by Step)

### Step 1 — Create the GitHub repo
1. Go to [github.com/new](https://github.com/new)
2. Name it: `xai-copilot`
3. Set to **Public** (required for free GitHub Pages)
4. **Do NOT** initialize with README (you already have one)
5. Click **Create repository**

### Step 2 — Push your code
```bash
cd xai-copilot

git init
git add .
git commit -m "feat: initial XAI Copilot — explainability + bias + appeal"

git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/xai-copilot.git
git push -u origin main
```

---

## 🌐 GitHub Pages Deployment (Frontend)

### Step 1 — Enable GitHub Pages
1. Go to your repo → **Settings** → **Pages**
2. Under **Source** → select **GitHub Actions**
3. Save

### Step 2 — Add your Render backend URL as a Secret
1. First deploy backend to Render (see section above)
2. Copy your Render backend URL e.g. `https://xai-copilot-api.onrender.com/api/v1`
3. In GitHub → **Settings** → **Secrets and variables** → **Actions**
4. Click **New repository secret**
   - Name: `VITE_API_URL`
   - Value: `https://xai-copilot-api.onrender.com/api/v1`
5. Save

### Step 3 — Trigger deployment
```bash
# Either push any change, or go to GitHub → Actions → Run workflow manually
git commit --allow-empty -m "trigger: deploy to GitHub Pages"
git push
```

### Step 4 — Your live URL
After ~2 minutes the workflow completes and your site is live at:
```
https://YOUR_USERNAME.github.io/xai-copilot/
```

---

## 🔄 Workflow Summary

```
You push code to main
        ↓
GitHub Actions builds React app
        ↓
Deploys to GitHub Pages (frontend)
        ↓
Frontend calls Render backend API
        ↓
Render runs FastAPI + ML model
```

---

## 💡 Pro Tips for Resume

1. Add the live GitHub Pages URL to your resume as a demo link
2. Add a **Loom video** walkthrough (2 min) and link it in the README
3. Pin the repo on your GitHub profile
4. Write a LinkedIn post: "Built an XAI Copilot for credit risk that explains AI decisions in plain English..."
