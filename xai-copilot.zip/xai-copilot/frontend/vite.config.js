import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Set your GitHub repo name here for GitHub Pages
// e.g. if your repo is github.com/yourname/xai-copilot → '/xai-copilot'
const REPO_NAME = '/xai-copilot'

export default defineConfig({
  plugins: [react()],
  // base is used for GitHub Pages — remove or set to '/' for Render/Vercel
  base: process.env.GITHUB_PAGES ? REPO_NAME : '/',
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true
      }
    }
  }
})
